import SwiftUI

@main
struct SpeechyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}